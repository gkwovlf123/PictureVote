package com.example.picturevote;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ResultActivity extends AppCompatActivity {

    Button btnback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        TextView[] textViews = new TextView[9];
        RatingBar[] ratingBars = new RatingBar[9];
        Integer[] textID = {R.id.textView,R.id.textView2,R.id.textView3,R.id.textView4,R.id.textView5,R.id.textView6,R.id.textView7,R.id.textView8,R.id.textView9};
        Integer[] RatID = {R.id.ratingBar,R.id.ratingBar2,R.id.ratingBar3,R.id.ratingBar4,R.id.ratingBar5,R.id.ratingBar6,R.id.ratingBar7,R.id.ratingBar8,R.id.ratingBar9};
        super.onCreate(savedInstanceState);

        String[] movienames = intent.getStringArrayExtra("Name");
        int[] movieRating = intent.getIntArrayExtra("num");
        for(int i=0;i<textID.length;i++)
        {
            textViews[i] = findViewById(textID[i]);
            ratingBars[i] = findViewById(RatID[i]);
        }
        for(int i=0;i<9;i++)
        {
            textViews[i].setText(movienames[i]);
            ratingBars[i].setRating(movieRating[i]);
        }
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}