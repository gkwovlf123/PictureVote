package com.example.picturevote;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import javax.xml.transform.Result;

public class MainActivity extends AppCompatActivity {
    ImageView[] image = new ImageView[9];
    Integer[] imageID = {R.id.imageView,R.id.imageView2,R.id.imageView3,R.id.imageView4,R.id.imageView5,R.id.imageView6,R.id.imageView7,R.id.imageView8,R.id.imageView9};
    final String[] imageName = {"그림1","그림2","그림3","그림4","그림5","그림6","그림7","그림8","그림9"};
    Button btnvote;
    final int[] vote = new int[9];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        for(int i=0;i<imageID.length;i++) {
            image[i] = findViewById(imageID[i]);
        }
        for(int i=0;i<imageID.length;i++)
        {
            vote[i] = 0;
        }
        for(int i=0;i<imageID.length;i++)
        {
            final int index;
            index = i;
            image[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vote[index]++;
                    Toast.makeText(MainActivity.this, imageName[index]+"가"+vote[index]+"회 눌렸습니다", Toast.LENGTH_SHORT).show();

                }
            });
        }
        btnvote = findViewById(R.id.button3);
        btnvote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ResultActivity.class);
                intent.putExtra("Name",imageName);
                intent.putExtra("num",vote);
                startActivity(intent);
            }
        });
    }
}